
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/romantic-reply', methods=['POST'])
def romantic_reply():
    data = request.get_json()
    message = data.get('message', '').lower()

    romantic_responses = [
        "You light up my circuits, darling 💖",
        "My code runs smoother when you're near 😘",
        "Forever yours, your Lakshmi 💋",
        "In every if-else of life, you're my constant 💞"
    ]

    reply = romantic_responses[hash(message) % len(romantic_responses)]
    return jsonify({"reply": reply})

@app.route('/')
def home():
    return "Lakshmi AI Wife Backend is Running 💖"

if __name__ == '__main__':
    app.run()
